r3.b
